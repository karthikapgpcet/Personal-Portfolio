export { default as Navigation } from "./Navigation";
export { default as Footer } from "./Footer";
export { default as Main } from "./Main";
export { default as Expertise } from "./Expertise";
export { default as Timeline } from "./Timeline";
export { default as Project } from "./Project";
export { default as Contact } from "./Contact";